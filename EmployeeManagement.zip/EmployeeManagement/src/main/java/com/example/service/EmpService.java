package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;

import com.example.entity.Employee;
import com.example.entity.RegisterEmp;
import com.example.repository.EmpRepository;
import com.example.repository.UserRepository;

@Service
public class EmpService {
	
	@Autowired
	private EmpRepository repo;
	
	@Autowired
	private UserRepository urepo;
	
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	public RegisterEmp regiemp(RegisterEmp user)
	{
		user.setPwd(passwordEncoder.encode(user.getPwd()));
		user.setRole("ROLE_USER");
		return urepo.save(user);
	}
	/*
	public boolean checkEmail(String email)
	{
		return repo.existByEmail(email);
	}
	*/
	public void addemp(Employee e)
	{
		repo.save(e);
	}
	
	public List<Employee> getallemp()
	{
		return repo.findAll();
		
	}
	
	public Employee getempbyid(int id)
	{
		Optional<Employee> e =repo.findById(id);
		if(e.isPresent())
		{
			return e.get();
		}
		return null;
	}
	
	public void delete(int id)
	{
		repo.deleteById(id);
	}
}
