package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.RegisterEmp;

@Repository
public interface UserRepository extends JpaRepository<RegisterEmp,Integer> {
	
	public  RegisterEmp findByEmail(String email);    // to check the email is exist in database for configuration

	//public RegisterEmp save(RegisterEmp user);

}
