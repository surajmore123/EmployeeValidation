package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Employee;


@Repository
public interface EmpRepository extends JpaRepository<Employee,Integer> {

	//public boolean existByEmail(String email);  // to check the email id is already exist or not in database
	/*
		public  RegisterEmp findByEmail(String email);    // to check the email is exist in database for configuration

		public RegisterEmp save(RegisterEmp user);
		*/
	

}
